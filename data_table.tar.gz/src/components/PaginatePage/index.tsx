export { default } from "./PaginatePage";
